# Nacho v1 — Voice-First AI Robot Assistant

## Overview

Nacho is a voice-first AI robot assistant with an animated robot face UI, designed to run as a kiosk-style web application (primarily on an iPad mounted on a mobile robot body). The system listens for a wake phrase ("Hey Nacho"), processes speech, sends it to an AI brain, generates responses with text-to-speech, and can control robot movement/navigation between saved rooms.

The app is a full-stack TypeScript monorepo with a React frontend (Vite), an Express backend, PostgreSQL database (via Drizzle ORM), and OpenAI-powered AI integrations for voice chat, speech-to-text, text-to-speech, and image generation.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Monorepo Structure
- **`client/`** — React SPA (Vite + TypeScript)
- **`server/`** — Express API server (TypeScript, compiled with esbuild)
- **`shared/`** — Shared types, schemas, and route definitions used by both client and server
- **`migrations/`** — Drizzle-generated database migrations

### Frontend (`client/src/`)
- **Framework**: React 18 with TypeScript, bundled by Vite
- **Routing**: Wouter (lightweight client-side router) — single main page (`Home`) plus a 404
- **State/Data Fetching**: TanStack React Query for all server communication
- **UI Components**: shadcn/ui (new-york style) built on Radix UI primitives, styled with Tailwind CSS
- **Design System**: Dark theme kiosk-optimized UI with custom CSS variables, glassmorphism effects, and custom `PrimaryButton`/`SecondaryButton` components
- **Key UI Components**:
  - `RobotFace` — Animated SVG robot face with states (idle, listening, thinking, speaking, navigating, error)
  - `StatusPill` — Shows current Nacho state
  - `MicMeter` — Visual microphone activity indicator
  - `RoomsCard` — Room management (list, add, set home base)
  - `MovementCard` — Navigation commands and movement history
  - `DevPanel` — Developer testing panel for simulating wake, text input, and pose
- **Voice Integration**: Custom hooks in `client/replit_integrations/audio/` handle:
  - `useVoiceRecorder` — MediaRecorder API for capturing audio (WebM/Opus)
  - `useAudioPlayback` — AudioWorklet-based streaming PCM16 playback with sequence buffering
  - `useVoiceStream` — SSE-based streaming voice responses from server
- **Path aliases**: `@/` → `client/src/`, `@shared/` → `shared/`, `@assets/` → `attached_assets/`

### Backend (`server/`)
- **Framework**: Express 5 on Node.js, using `tsx` for development
- **Entry point**: `server/index.ts` creates HTTP server, registers routes, sets up Vite dev middleware or serves static build
- **API Design**: REST endpoints defined in `shared/routes.ts` with Zod schemas for input validation and typed responses. The `api` object serves as a single source of truth for paths, methods, and schemas.
- **Key API Routes**:
  - `POST /api/wake` — Wake phrase detection
  - `POST /api/chat` — AI chat with intent detection (move, save_room, stop, chat)
  - `POST /api/move` / `GET /api/move` / `POST /api/move/stop` — Movement commands
  - `GET /api/rooms` / `POST /api/rooms` / `POST /api/rooms/:id/home-base` — Room management
  - `GET/POST/DELETE /api/conversations` — Voice conversation CRUD
  - `POST /api/conversations/:id/messages` — SSE streaming voice messages (audio in, transcript + audio out)
  - `POST /api/generate-image` — Image generation
- **Intent Detection**: Server-side NLP parses user messages to detect navigation commands, room-saving requests, stop commands, or general chat
- **Storage Layer**: `server/storage.ts` implements `IStorage` interface using Drizzle ORM with PostgreSQL — handles rooms, movements, conversations, and messages

### Database
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Connection**: `node-postgres` Pool via `DATABASE_URL` environment variable
- **Schema** (in `shared/schema.ts` and `shared/models/chat.ts`):
  - `users` — id (UUID), username, password
  - `rooms` — id, name, locationData (JSONB with x/y/heading), isHomeBase, createdAt
  - `movements` — id, command, destination, status, detail, createdAt
  - `conversations` — id, title, createdAt
  - `messages` — id, conversationId (FK), role, content, createdAt
- **Schema push**: `npm run db:push` uses `drizzle-kit push`
- **Seed data**: Server seeds default rooms (Kitchen, Living Room, Bedroom) on first run if none exist

### AI Integrations (`server/replit_integrations/`)
- **Audio** (`audio/`): OpenAI-powered speech-to-text, text-to-speech, and voice chat with streaming SSE responses. Handles audio format detection (WAV, WebM, MP3, MP4, OGG) and ffmpeg conversion.
- **Chat** (`chat/`): Conversation storage and OpenAI chat completions
- **Image** (`image/`): Image generation via `gpt-image-1` model
- **Batch** (`batch/`): Generic batch processing utility with rate limiting and retries (p-limit, p-retry)

### Build Process
- **Dev**: `tsx server/index.ts` with Vite dev server middleware (HMR via WebSocket at `/vite-hmr`)
- **Build**: `script/build.ts` runs Vite build for client → `dist/public/`, then esbuild for server → `dist/index.cjs`. Bundles selected server dependencies to reduce cold start syscalls.
- **Production**: `node dist/index.cjs` serves static files from `dist/public/`

## External Dependencies

### Required Services
- **PostgreSQL**: Primary database, connected via `DATABASE_URL` environment variable
- **OpenAI API** (via Replit AI Integrations): Used for chat completions, speech-to-text, text-to-speech, and image generation. Configured via:
  - `AI_INTEGRATIONS_OPENAI_API_KEY`
  - `AI_INTEGRATIONS_OPENAI_BASE_URL`
- **ffmpeg**: Required on the system for audio format conversion (WebM/MP4 → WAV for speech-to-text)

### Key NPM Packages
- **Frontend**: React, Wouter, TanStack React Query, Radix UI, Tailwind CSS, shadcn/ui, Lucide icons, recharts, embla-carousel, react-day-picker, vaul (drawer), react-hook-form + zod
- **Backend**: Express 5, Drizzle ORM, pg (node-postgres), OpenAI SDK, nanoid, zod, express-session, connect-pg-simple, passport
- **Build**: Vite, esbuild, tsx, TypeScript, @replit/vite-plugin-runtime-error-modal