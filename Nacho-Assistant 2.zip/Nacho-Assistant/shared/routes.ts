import { z } from "zod";
import {
  chatRequestSchema,
  moveRequestSchema,
  saveRoomRequestSchema,
  wakeRequestSchema,
  rooms,
  movements,
} from "./schema";

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  wake: {
    create: {
      method: "POST" as const,
      path: "/api/wake" as const,
      input: wakeRequestSchema,
      responses: {
        200: z.object({ ok: z.literal(true), wokeAt: z.string() }),
        400: errorSchemas.validation,
      },
    },
  },
  chat: {
    create: {
      method: "POST" as const,
      path: "/api/chat" as const,
      input: chatRequestSchema,
      responses: {
        200: z.object({
          session_id: z.string(),
          response: z.string(),
          intent: z
            .union([
              z.object({ type: z.literal("move"), command: z.string(), destination: z.string().optional() }),
              z.object({ type: z.literal("save_room"), room_name: z.string() }),
              z.object({ type: z.literal("stop") }),
              z.object({ type: z.literal("chat") }),
            ])
            .optional(),
        }),
        400: errorSchemas.validation,
        500: errorSchemas.internal,
      },
    },
  },
  move: {
    create: {
      method: "POST" as const,
      path: "/api/move" as const,
      input: moveRequestSchema,
      responses: {
        201: z.custom<typeof movements.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    stop: {
      method: "POST" as const,
      path: "/api/move/stop" as const,
      input: z.object({}).optional(),
      responses: {
        200: z.object({ ok: z.literal(true) }),
      },
    },
    list: {
      method: "GET" as const,
      path: "/api/movements" as const,
      input: z
        .object({
          limit: z.coerce.number().int().positive().max(100).optional(),
        })
        .optional(),
      responses: {
        200: z.array(z.custom<typeof movements.$inferSelect>()),
      },
    },
  },
  rooms: {
    list: {
      method: "GET" as const,
      path: "/api/rooms" as const,
      responses: {
        200: z.array(z.custom<typeof rooms.$inferSelect>()),
      },
    },
    create: {
      method: "POST" as const,
      path: "/api/save_room" as const,
      input: saveRoomRequestSchema,
      responses: {
        201: z.custom<typeof rooms.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    setHomeBase: {
      method: "POST" as const,
      path: "/api/rooms/:id/home_base" as const,
      input: z.object({}).optional(),
      responses: {
        200: z.custom<typeof rooms.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
  voice: {
    conversations: {
      list: { method: "GET" as const, path: "/api/conversations" as const },
      get: { method: "GET" as const, path: "/api/conversations/:id" as const },
      create: { method: "POST" as const, path: "/api/conversations" as const },
      delete: { method: "DELETE" as const, path: "/api/conversations/:id" as const },
      message: { method: "POST" as const, path: "/api/conversations/:id/messages" as const },
    },
  },
} as const;

export function buildUrl(
  path: string,
  params?: Record<string, string | number>
): string {
  let url = path;
  if (params) {
    for (const [key, value] of Object.entries(params)) {
      url = url.replace(`:${key}`, String(value));
    }
  }
  return url;
}

export type WakeInput = z.infer<typeof api.wake.create.input>;
export type WakeOk = z.infer<typeof api.wake.create.responses[200]>;

export type ChatInput = z.infer<typeof api.chat.create.input>;
export type ChatOk = z.infer<typeof api.chat.create.responses[200]>;

export type MoveInput = z.infer<typeof api.move.create.input>;
export type MoveCreated = z.infer<typeof api.move.create.responses[201]>;

export type SaveRoomInput = z.infer<typeof api.rooms.create.input>;
export type SaveRoomCreated = z.infer<typeof api.rooms.create.responses[201]>;

export type RoomList = z.infer<typeof api.rooms.list.responses[200]>;
export type MovementList = z.infer<typeof api.move.list.responses[200]>;

export type ValidationError = z.infer<typeof errorSchemas.validation>;
export type NotFoundError = z.infer<typeof errorSchemas.notFound>;
export type InternalError = z.infer<typeof errorSchemas.internal>;
