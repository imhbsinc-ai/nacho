import { sql } from "drizzle-orm";
import {
  boolean,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export * from "./models/chat";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const rooms = pgTable("rooms", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  locationData: jsonb("location_data").notNull(),
  isHomeBase: boolean("is_home_base").notNull().default(false),
  createdAt: timestamp("created_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
});

export const movements = pgTable("movements", {
  id: serial("id").primaryKey(),
  command: text("command").notNull(),
  destination: text("destination"),
  status: text("status").notNull().default("queued"),
  detail: text("detail"),
  createdAt: timestamp("created_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
});

export const insertRoomSchema = createInsertSchema(rooms).omit({
  id: true,
  createdAt: true,
});

export const insertMovementSchema = createInsertSchema(movements).omit({
  id: true,
  createdAt: true,
});

export type Room = typeof rooms.$inferSelect;
export type InsertRoom = z.infer<typeof insertRoomSchema>;

export type Movement = typeof movements.$inferSelect;
export type InsertMovement = z.infer<typeof insertMovementSchema>;

export type CreateRoomRequest = InsertRoom;
export type UpdateRoomRequest = Partial<InsertRoom>;
export type RoomResponse = Room;
export type RoomsListResponse = Room[];

export type CreateMovementRequest = InsertMovement;
export type MovementResponse = Movement;

export const wakeRequestSchema = z.object({
  wake: z.literal("nacho"),
});
export type WakeRequest = z.infer<typeof wakeRequestSchema>;
export type WakeResponse = { ok: true; wokeAt: string };

export const chatRequestSchema = z.object({
  message: z.string().min(1),
  session_id: z.string().min(1).optional(),
});
export type ChatRequest = z.infer<typeof chatRequestSchema>;
export type ChatResponse = {
  session_id: string;
  response: string;
  intent?:
    | { type: "move"; destination?: string; command: string }
    | { type: "save_room"; room_name: string }
    | { type: "stop" }
    | { type: "chat" };
};

export const moveRequestSchema = z.object({
  destination: z.string().min(1).optional(),
  command: z.string().min(1),
});
export type MoveRequest = z.infer<typeof moveRequestSchema>;
export type MoveResponse = MovementResponse;

export const saveRoomRequestSchema = z.object({
  room_name: z.string().min(1),
  location_data: z.unknown(),
  is_home_base: z.boolean().optional(),
});
export type SaveRoomRequest = z.infer<typeof saveRoomRequestSchema>;
export type SaveRoomResponse = RoomResponse;
