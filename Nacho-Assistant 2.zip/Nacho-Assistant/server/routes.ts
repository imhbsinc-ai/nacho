import type { Express } from "express";
import type { Server } from "http";
import { z } from "zod";
import { api } from "@shared/routes";
import { storage } from "./storage";
import { registerAudioRoutes } from "./replit_integrations/audio";
import {
  chatRequestSchema,
  moveRequestSchema,
  saveRoomRequestSchema,
  wakeRequestSchema,
} from "@shared/schema";

function zodErrorToResponse(err: z.ZodError) {
  const first = err.errors[0];
  return {
    message: first?.message ?? "Invalid request",
    field: first?.path?.length ? first.path.join(".") : undefined,
  };
}

async function seedDatabase() {
  const rooms = await storage.listRooms();
  if (rooms.length > 0) return;

  await storage.createOrUpdateRoom({
    name: "Kitchen",
    locationData: { x: 2.4, y: 1.2, heading: 90 },
    isHomeBase: false,
  });

  await storage.createOrUpdateRoom({
    name: "Living Room",
    locationData: { x: 0.5, y: 3.1, heading: 10 },
    isHomeBase: true,
  });

  await storage.createOrUpdateRoom({
    name: "Bedroom",
    locationData: { x: -1.2, y: 4.0, heading: 180 },
    isHomeBase: false,
  });
}

function detectIntent(message: string):
  | { type: "move"; command: string; destination?: string }
  | { type: "save_room"; room_name: string }
  | { type: "stop" }
  | { type: "chat" } {
  const text = message.trim().toLowerCase();

  if (/(^|\b)stop(\b|$)/.test(text) || text.includes("stop moving")) {
    return { type: "stop" };
  }

  const goToMatch = text.match(/\bgo to\s+(.+)$/);
  if (goToMatch?.[1]) {
    return { type: "move", command: "go_to", destination: goToMatch[1].trim() };
  }

  if (text.includes("follow me")) return { type: "move", command: "follow_me" };
  if (text.includes("come here")) return { type: "move", command: "come_here" };
  if (text.includes("return home base") || text.includes("go home")) {
    return { type: "move", command: "return_home_base" };
  }

  const thisIsMatch = text.match(/\bthis is the\s+(.+)$/);
  if (thisIsMatch?.[1]) {
    const roomName = thisIsMatch[1].trim();
    if (roomName) return { type: "save_room", room_name: roomName };
  }

  return { type: "chat" };
}

export async function registerRoutes(
  httpServer: Server,
  app: Express,
): Promise<Server> {
  await seedDatabase();

  // Voice routes (/api/conversations...) from integration
  registerAudioRoutes(app);

  app.post(api.wake.create.path, async (req, res) => {
    try {
      const input = wakeRequestSchema.parse(req.body);
      if (input.wake !== "nacho") {
        return res.status(400).json({ message: "Invalid wake value", field: "wake" });
      }
      return res.json({ ok: true, wokeAt: new Date().toISOString() });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json(zodErrorToResponse(err));
      }
      throw err;
    }
  });

  app.get(api.rooms.list.path, async (_req, res) => {
    const rooms = await storage.listRooms();
    res.json(rooms);
  });

  app.post(api.rooms.create.path, async (req, res) => {
    try {
      const input = saveRoomRequestSchema.parse(req.body);
      const created = await storage.createOrUpdateRoom({
        name: input.room_name,
        locationData: input.location_data,
        isHomeBase: input.is_home_base ?? false,
      });
      res.status(201).json(created);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json(zodErrorToResponse(err));
      }
      throw err;
    }
  });

  app.post(api.rooms.setHomeBase.path, async (req, res) => {
    const roomId = Number(req.params.id);
    if (!Number.isFinite(roomId)) {
      return res.status(404).json({ message: "Room not found" });
    }

    const rooms = await storage.listRooms();
    const found = rooms.find((r) => r.id === roomId);
    if (!found) {
      return res.status(404).json({ message: "Room not found" });
    }

    const updated = await storage.setHomeBase(roomId);
    res.json(updated);
  });

  app.get(api.move.list.path, async (req, res) => {
    const parsedLimit = req.query.limit ? Number(req.query.limit) : undefined;
    const limit = Number.isFinite(parsedLimit) ? parsedLimit : undefined;
    const movements = await storage.listMovements(limit);
    res.json(movements);
  });

  app.post(api.move.create.path, async (req, res) => {
    try {
      const input = moveRequestSchema.parse(req.body);
      const created = await storage.createMovement({
        command: input.command,
        destination: input.destination,
        status: "queued",
        detail: "Command received",
      });
      res.status(201).json(created);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json(zodErrorToResponse(err));
      }
      throw err;
    }
  });

  app.post(api.move.stop.path, async (_req, res) => {
    const ok = await storage.stopMovement();
    res.json(ok);
  });

  app.post(api.chat.create.path, async (req, res) => {
    try {
      const input = chatRequestSchema.parse(req.body);
      const intent = detectIntent(input.message);

      if (intent.type === "stop") {
        await storage.stopMovement();
        return res.json({
          session_id: input.session_id ?? "default",
          response: "Stopping now.",
          intent,
        });
      }

      if (intent.type === "save_room") {
        await storage.createOrUpdateRoom({
          name: intent.room_name,
          locationData: { x: 0, y: 0, heading: 0 },
          isHomeBase: false,
        });
        return res.json({
          session_id: input.session_id ?? "default",
          response: `Saved ${intent.room_name}.`,
          intent,
        });
      }

      if (intent.type === "move") {
        if (intent.command === "return_home_base") {
          const rooms = await storage.listRooms();
          const home = rooms.find((r) => r.isHomeBase);
          await storage.createMovement({
            command: intent.command,
            destination: home?.name ?? "home base",
            status: "queued",
            detail: "Navigating home base",
          });
        } else {
          await storage.createMovement({
            command: intent.command,
            destination: intent.destination,
            status: "queued",
            detail: "Navigating",
          });
        }

        return res.json({
          session_id: input.session_id ?? "default",
          response: intent.destination
            ? `Okay. Going to ${intent.destination}.`
            : "Okay.",
          intent,
        });
      }

      return res.json({
        session_id: input.session_id ?? "default",
        response: "Okay.",
        intent,
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json(zodErrorToResponse(err));
      }
      throw err;
    }
  });

  return httpServer;
}
