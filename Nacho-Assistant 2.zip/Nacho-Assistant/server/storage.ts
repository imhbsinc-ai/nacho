import { db } from "./db";
import {
  movements,
  rooms,
  type CreateMovementRequest,
  type CreateRoomRequest,
  type MovementResponse,
  type RoomResponse,
  type RoomsListResponse,
} from "@shared/schema";
import { and, desc, eq, ilike } from "drizzle-orm";

export interface IStorage {
  listRooms(): Promise<RoomsListResponse>;
  getRoomByName(name: string): Promise<RoomResponse | undefined>;
  createOrUpdateRoom(room: CreateRoomRequest): Promise<RoomResponse>;
  setHomeBase(roomId: number): Promise<RoomResponse>;

  createMovement(req: CreateMovementRequest): Promise<MovementResponse>;
  listMovements(limit?: number): Promise<MovementResponse[]>;
  stopMovement(): Promise<{ ok: true }>;
}

export class DatabaseStorage implements IStorage {
  async listRooms(): Promise<RoomsListResponse> {
    return db.select().from(rooms).orderBy(rooms.name);
  }

  async getRoomByName(name: string): Promise<RoomResponse | undefined> {
    const [room] = await db
      .select()
      .from(rooms)
      .where(ilike(rooms.name, name));
    return room;
  }

  async createOrUpdateRoom(room: CreateRoomRequest): Promise<RoomResponse> {
    const existing = await this.getRoomByName(room.name);
    if (existing) {
      const [updated] = await db
        .update(rooms)
        .set({
          locationData: room.locationData,
          isHomeBase: room.isHomeBase ?? existing.isHomeBase,
        })
        .where(eq(rooms.id, existing.id))
        .returning();
      return updated;
    }

    const [created] = await db.insert(rooms).values(room).returning();
    return created;
  }

  async setHomeBase(roomId: number): Promise<RoomResponse> {
    await db.update(rooms).set({ isHomeBase: false });
    const [updated] = await db
      .update(rooms)
      .set({ isHomeBase: true })
      .where(eq(rooms.id, roomId))
      .returning();
    return updated;
  }

  async createMovement(req: CreateMovementRequest): Promise<MovementResponse> {
    const [created] = await db.insert(movements).values(req).returning();
    return created;
  }

  async listMovements(limit = 25): Promise<MovementResponse[]> {
    return db
      .select()
      .from(movements)
      .orderBy(desc(movements.createdAt))
      .limit(limit);
  }

  async stopMovement(): Promise<{ ok: true }> {
    const [latest] = await db
      .select()
      .from(movements)
      .orderBy(desc(movements.createdAt))
      .limit(1);

    if (latest && (latest.status === "queued" || latest.status === "running")) {
      await db
        .update(movements)
        .set({ status: "stopped", detail: "Stopped by voice" })
        .where(eq(movements.id, latest.id));
    }

    return { ok: true };
  }
}

export const storage = new DatabaseStorage();
