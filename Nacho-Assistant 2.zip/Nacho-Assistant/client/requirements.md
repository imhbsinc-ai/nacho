## Packages
(none needed)

## Notes
Use the provided audio worklet at /audio-playback-worklet.js — copy or serve client/replit_integrations/audio/audio-playback-worklet.js from public root (assumed available).
SSE voice streaming endpoint: POST /api/conversations/:id/messages returns text/event-stream with events {type:user_transcript|transcript|audio|done|error}.
All fetches must include credentials: "include".
