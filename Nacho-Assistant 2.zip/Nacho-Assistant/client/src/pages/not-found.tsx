import { Link } from "wouter";
import { KioskShell } from "@/components/KioskShell";
import { PrimaryButton } from "@/components/PrimaryButton";
import { AlertTriangle } from "lucide-react";

export default function NotFound() {
  return (
    <KioskShell>
      <div className="min-h-[70vh] flex items-center justify-center">
        <div className="glass rounded-[2.25rem] p-8 md:p-10 max-w-xl w-full glow-ring animate-float-in">
          <div className="flex items-start gap-4">
            <div className="h-12 w-12 rounded-2xl bg-destructive/15 border border-destructive/25 flex items-center justify-center">
              <AlertTriangle className="h-6 w-6 text-destructive" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl">Page not found</h1>
              <p className="mt-2 text-muted-foreground">
                This kiosk only runs the main interface.
              </p>
            </div>
          </div>

          <div className="mt-6">
            <Link href="/" className="block">
              <PrimaryButton onClick={() => {}} className="w-full" testId="go-home">
                Return to Nacho
              </PrimaryButton>
            </Link>
          </div>
        </div>
      </div>
    </KioskShell>
  );
}
