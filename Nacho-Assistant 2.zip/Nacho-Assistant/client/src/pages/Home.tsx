import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "wouter";
import { KioskShell } from "@/components/KioskShell";
import { RobotFace } from "@/components/RobotFace";
import { MicMeter } from "@/components/MicMeter";
import { StatusPill, type NachoState } from "@/components/StatusPill";
import { DevPanel, type SimPose } from "@/components/DevPanel";
import { RoomsCard } from "@/components/RoomsCard";
import { MovementCard } from "@/components/MovementCard";
import { PrimaryButton } from "@/components/PrimaryButton";
import { SecondaryButton } from "@/components/SecondaryButton";
import { useToast } from "@/hooks/use-toast";
import { LayoutGrid } from "lucide-react";

import { useWake } from "@/hooks/use-wake";
import { useChat } from "@/hooks/use-chat";
import { useCreateMove, useMovements, useStopMove } from "@/hooks/use-move";
import { useRooms, useSaveRoom, useSetHomeBase } from "@/hooks/use-rooms";
import {
  useCreateConversation,
  useVoiceConversations,
} from "@/hooks/use-voice";

import { useVoiceRecorder, useVoiceStream } from "../../replit_integrations/audio";
import { api, buildUrl } from "@shared/routes";
import type { Movement } from "@shared/schema";

type Turn = {
  id: string;
  at: number;
  user?: string;
  assistant?: string;
  intent?: string;
};

function uid() {
  return Math.random().toString(16).slice(2) + "-" + Date.now().toString(16);
}

export default function Home() {
  const { toast } = useToast();

  const [state, setState] = useState<NachoState>("idle");
  const [subtitle, setSubtitle] = useState<string>(
    "Listening for: Hey Nacho",
  );
  const [devOpen, setDevOpen] = useState(false);

  const [pose, setPose] = useState<SimPose>({ x: 0, y: 0, heading: 0 });

  const [sessionId, setSessionId] = useState<string | undefined>(undefined);
  const [turns, setTurns] = useState<Turn[]>([]);
  const [lastUserTranscript, setLastUserTranscript] = useState<string>("");
  const [assistantTranscript, setAssistantTranscript] = useState<string>("");

  const recorder = useVoiceRecorder();

  const wake = useWake();
  const chat = useChat();
  const createMove = useCreateMove();
  const stopMove = useStopMove();

  const roomsQ = useRooms();
  const saveRoom = useSaveRoom();
  const setHome = useSetHomeBase();

  const movementsQ = useMovements(12);

  const convosQ = useVoiceConversations();
  const createConvo = useCreateConversation();

  const activeConversationIdRef = useRef<number | null>(null);

  // Prefer using the voice endpoints (audio streaming) for kiosk.
  const voiceStream = useVoiceStream({
    onUserTranscript: (t) => {
      setLastUserTranscript(t);
      setTurns((prev) => [{ id: uid(), at: Date.now(), user: t }, ...prev].slice(0, 12));
    },
    onTranscript: (_, full) => {
      setAssistantTranscript(full);
      setState("speaking");
      setSubtitle("Speaking");
      setTurns((prev) => {
        const head = prev[0];
        if (!head) return prev;
        // attach assistant draft to latest turn
        const next = [...prev];
        next[0] = { ...head, assistant: full };
        return next;
      });
    },
    onComplete: () => {
      setState("idle");
      setSubtitle("Listening for: Hey Nacho");
    },
    onError: (e) => {
      console.error(e);
      setState("error");
      setSubtitle("Something went wrong");
      toast({
        title: "Voice error",
        description: e.message,
        variant: "destructive",
      });
    },
  });

  const busy =
    wake.isPending ||
    chat.isPending ||
    createMove.isPending ||
    stopMove.isPending ||
    saveRoom.isPending ||
    setHome.isPending ||
    recorder.state === "recording" ||
    state === "thinking" ||
    state === "speaking";

  const latestMovement = useMemo<Movement | null>(() => {
    const list = movementsQ.data ?? [];
    return list.length ? (list[0] as any) : null;
  }, [movementsQ.data]);

  // Ensure there's a conversation ready
  useEffect(() => {
    if (activeConversationIdRef.current) return;
    const existing = convosQ.data?.[0];
    if (existing?.id) {
      activeConversationIdRef.current = existing.id;
      return;
    }
    if (convosQ.isLoading) return;
    // Create one in background for first use
    createConvo.mutate("Nacho Kiosk", {
      onSuccess: (c) => {
        activeConversationIdRef.current = c.id;
      },
      onError: () => {
        // Non-fatal; we can still use text endpoints
      },
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [convosQ.data, convosQ.isLoading]);

  useEffect(() => {
    if (state === "idle" && !busy) {
      console.log("passive listening");
      const recognition = new (window as any).webkitSpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = "en-US";

      recognition.onresult = (event: any) => {
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            const transcript = event.results[i][0].transcript.toLowerCase();
            if (transcript.includes("hey nacho")) {
              console.log("wake word detected");
              recognition.stop();
              wakeAndListen();
            }
          }
        }
      };

      recognition.onend = () => {
        if (state === "idle" && !busy) {
          recognition.start();
        }
      };

      recognition.start();
      return () => recognition.stop();
    }
  }, [state, busy]);

  useEffect(() => {
    if (state === "speaking") {
      console.log("speaking animation active");
    } else if (state === "idle") {
      console.log("returning to passive mode");
    }
  }, [state]);

  async function runTextTurn(text: string) {
    try {
      setState("thinking");
      setSubtitle("Thinking");
      const turnId = uid();
      setTurns((prev) => [{ id: turnId, at: Date.now(), user: text }, ...prev].slice(0, 12));

      const res = await chat.mutateAsync({ message: text, session_id: sessionId });
      setSessionId(res.session_id);

      const intent = res.intent?.type;
      setTurns((prev) => {
        const next = [...prev];
        const idx = next.findIndex((t) => t.id === turnId);
        if (idx >= 0) {
          next[idx] = { ...next[idx], assistant: res.response, intent };
        }
        return next;
      });

      setAssistantTranscript(res.response);

      // Act on intent if present
      if (res.intent?.type === "move") {
        setState("navigating");
        setSubtitle(`Navigating${res.intent.destination ? `: ${res.intent.destination}` : ""}`);
        await createMove.mutateAsync({
          command: res.intent.command,
          destination: res.intent.destination,
        });
        setState("idle");
        setSubtitle("Listening for: Hey Nacho");
      } else if (res.intent?.type === "save_room") {
        setSubtitle("Saving room");
        await saveRoom.mutateAsync({
          room_name: res.intent.room_name,
          location_data: pose,
        } as any);
        setState("idle");
        setSubtitle("Listening for: Hey Nacho");
      } else if (res.intent?.type === "stop") {
        setSubtitle("Stopping");
        await stopMove.mutateAsync();
        setState("idle");
        setSubtitle("Listening for: Hey Nacho");
      } else {
        setState("idle");
        setSubtitle("Listening for: Hey Nacho");
      }
    } catch (e: any) {
      setState("error");
      setSubtitle("Error");
      toast({
        title: "Request failed",
        description: e?.message ?? "Unknown error",
        variant: "destructive",
      });
    }
  }

  async function wakeAndListen() {
    // Simulated: user taps wake, then we record for up to 15s and send.
    try {
      setState("listening");
      setSubtitle("Listening…");
      await wake.mutateAsync({ wake: "nacho" });

      // After a successful wake, let Nacho acknowledge verbally
      const id = activeConversationIdRef.current;
      if (id) {
        // We'll create a "wake response" turn
        setTurns((prev) => [{ id: uid(), at: Date.now(), assistant: "I'm listening." }, ...prev].slice(0, 12));
        setAssistantTranscript("I'm listening.");
        setState("speaking");
        
        // Short delay to allow the "I'm listening" UI to show before starting recording
        // In a real voice-first system, we'd wait for TTS to finish.
        setTimeout(async () => {
          setState("listening");
          setSubtitle("Listening…");
          await recorder.startRecording();
          
          // auto-stop after 15s
          setTimeout(async () => {
            if (recorder.state !== "recording") return;
            const blob = await recorder.stopRecording();
            await sendVoiceBlob(blob);
          }, 15000);
        }, 1000);
      } else {
        // Fallback if no conversation
        await recorder.startRecording();
      }
    } catch (e: any) {
      setState("error");
      setSubtitle("Wake failed");
      toast({
        title: "Wake failed",
        description: e?.message ?? "Unknown error",
        variant: "destructive",
      });
    }
  }

  async function stopRecordingAndSend() {
    try {
      if (recorder.state !== "recording") return;
      const blob = await recorder.stopRecording();
      await sendVoiceBlob(blob);
    } catch (e: any) {
      setState("error");
      setSubtitle("Recording failed");
      toast({
        title: "Recording failed",
        description: e?.message ?? "Unknown error",
        variant: "destructive",
      });
    }
  }

  async function sendVoiceBlob(blob: Blob) {
    const id = activeConversationIdRef.current;
    if (!id) {
      // fall back to text mode
      await runTextTurn("Hey Nacho");
      return;
    }
    try {
      setState("thinking");
      setSubtitle("Thinking");
      const url = buildUrl(api.voice.conversations.message.path, { id });
      await voiceStream.streamVoiceResponse(url, blob);
      // Voice stream callbacks drive state transitions.
    } catch (e: any) {
      setState("error");
      setSubtitle("Voice failed");
      toast({
        title: "Voice failed",
        description: e?.message ?? "Unknown error",
        variant: "destructive",
      });
    }
  }

  const listeningActive = state === "listening" || recorder.state === "recording";

  return (
    <KioskShell>
      <div className="grid grid-cols-1 lg:grid-cols-[1.1fr_0.9fr] gap-5 lg:gap-6 items-start">
        <div className="space-y-5">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex flex-col gap-2">
              <StatusPill
                testId="nacho-status"
                state={state}
                subtitle={subtitle}
              />
              <div
                data-testid="listening-line"
                className="text-xs sm:text-sm text-muted-foreground"
              >
                Listening for: <span className="text-foreground/90 font-semibold">Hey Nacho</span>
                <span className="mx-2 text-muted-foreground/60">•</span>
                Connection:{" "}
                <span className="text-foreground/90 font-semibold">
                  {voiceStream.playbackState === "playing" ? "Audio active" : "Ready"}
                </span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              {recorder.state !== "recording" ? (
                <PrimaryButton
                  testId="wake-button"
                  disabled={busy}
                  onClick={wakeAndListen}
                >
                  Wake + Speak
                </PrimaryButton>
              ) : (
                <PrimaryButton
                  testId="send-voice"
                  disabled={busy && recorder.state !== "recording"}
                  onClick={stopRecordingAndSend}
                >
                  Stop + Send
                </PrimaryButton>
              )}

              <SecondaryButton
                testId="interrupt-stop"
                disabled={stopMove.isPending}
                onClick={() => {
                  setState("thinking");
                  setSubtitle("Stopping");
                  stopMove.mutate(undefined, {
                    onSuccess: () => {
                      setState("idle");
                      setSubtitle("Listening for: Hey Nacho");
                    },
                    onError: (e: any) => {
                      setState("error");
                      setSubtitle("Stop failed");
                      toast({
                        title: "Stop failed",
                        description: e?.message ?? "Unknown error",
                        variant: "destructive",
                      });
                    },
                  });
                }}
              >
                Stop moving
              </SecondaryButton>

              <SecondaryButton
                testId="toggle-dev"
                disabled={false}
                onClick={() => setDevOpen((v) => !v)}
              >
                Dev
              </SecondaryButton>

              <Link href="/spatial">
                <SecondaryButton
                  testId="link-spatial"
                  disabled={false}
                  onClick={() => {}}
                >
                  <LayoutGrid className="mr-2 h-4 w-4" />
                  Spatial
                </SecondaryButton>
              </Link>
            </div>
          </div>

          <RobotFace
            testId="nacho-face"
            state={state}
            subtitle={
              state === "listening"
                ? "Speak naturally. Short commands work best."
                : state === "thinking"
                  ? "Processing…"
                  : state === "speaking"
                    ? "Responding…"
                    : state === "navigating"
                      ? "Moving…"
                      : state === "error"
                        ? "I didn’t catch that. Try again."
                        : "Say “Hey Nacho” to begin."
            }
            className="breathe"
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <MicMeter
              testId="mic-meter"
              active={listeningActive}
              className="w-full"
            />
            <div className="glass rounded-2xl p-4 md:p-5 glow-ring">
              <div className="text-xs text-muted-foreground">Transcript</div>
              <div className="mt-2 space-y-2">
                <div className="rounded-2xl border border-border/70 bg-[hsl(var(--card))/0.35] p-3">
                  <div className="text-xs text-muted-foreground">You</div>
                  <div
                    data-testid="transcript-user"
                    className="mt-1 text-sm text-foreground/95 min-h-6"
                  >
                    {lastUserTranscript || "—"}
                  </div>
                </div>
                <div className="rounded-2xl border border-border/70 bg-[hsl(var(--card))/0.35] p-3">
                  <div className="text-xs text-muted-foreground">Nacho</div>
                  <div
                    data-testid="transcript-assistant"
                    className="mt-1 text-sm text-foreground/95 min-h-6"
                  >
                    {assistantTranscript || "—"}
                  </div>
                </div>
              </div>
              <div className="mt-3 text-xs text-muted-foreground">
                Tip: While speaking, Nacho won’t listen. Use “Wake + Speak” again to
                interrupt.
              </div>
            </div>
          </div>

          <DevPanel
            className="hidden md:block"
            open={devOpen}
            onToggle={() => setDevOpen((v) => !v)}
            onWakeClick={() => {
              setState("listening");
              setSubtitle("Simulated wake");
              wake.mutate(
                { wake: "nacho" },
                {
                  onSuccess: () => {
                    setState("idle");
                    setSubtitle("Listening for: Hey Nacho");
                  },
                  onError: (e: any) => {
                    setState("error");
                    setSubtitle("Wake failed");
                    toast({
                      title: "Wake failed",
                      description: e?.message ?? "Unknown error",
                      variant: "destructive",
                    });
                  },
                },
              );
            }}
            onSendText={(t) => {
              setLastUserTranscript(t);
              runTextTurn(t);
            }}
            onSetPose={(p) => setPose(p)}
            pose={pose}
            busy={busy}
          />
        </div>

        <div className="space-y-5 lg:sticky lg:top-8">
          <RoomsCard
            rooms={roomsQ.data ?? []}
            pose={pose}
            saving={saveRoom.isPending}
            settingHome={setHome.isPending}
            onSetHomeBase={(id) => {
              setHome.mutate(id, {
                onSuccess: () => {
                  toast({
                    title: "Home base set",
                    description: "Nacho will return here when asked.",
                  });
                },
                onError: (e: any) =>
                  toast({
                    title: "Failed to set home base",
                    description: e?.message ?? "Unknown error",
                    variant: "destructive",
                  }),
              });
            }}
            onSaveRoom={(input) => {
              saveRoom.mutate(
                {
                  room_name: input.room_name,
                  location_data: input.location_data,
                  is_home_base: input.is_home_base,
                } as any,
                {
                  onSuccess: () =>
                    toast({
                      title: "Room saved",
                      description: `Saved “${input.room_name}”.`,
                    }),
                  onError: (e: any) =>
                    toast({
                      title: "Failed to save room",
                      description: e?.message ?? "Unknown error",
                      variant: "destructive",
                    }),
                },
              );
            }}
          />

          <MovementCard
            latest={latestMovement}
            list={(movementsQ.data ?? []) as any}
            stopping={stopMove.isPending}
            busy={busy}
            onStop={() => {
              setState("thinking");
              setSubtitle("Stopping");
              stopMove.mutate(undefined, {
                onSuccess: () => {
                  setState("idle");
                  setSubtitle("Listening for: Hey Nacho");
                },
                onError: (e: any) => {
                  setState("error");
                  setSubtitle("Stop failed");
                  toast({
                    title: "Stop failed",
                    description: e?.message ?? "Unknown error",
                    variant: "destructive",
                  });
                },
              });
            }}
            onQuickCommand={(cmd) => {
              setLastUserTranscript(cmd);
              runTextTurn(cmd);
            }}
          />

          <div className="md:hidden">
            <DevPanel
              open={devOpen}
              onToggle={() => setDevOpen((v) => !v)}
              onWakeClick={() => {
                setState("listening");
                setSubtitle("Simulated wake");
                wake.mutate(
                  { wake: "nacho" },
                  {
                    onSuccess: () => {
                      setState("idle");
                      setSubtitle("Listening for: Hey Nacho");
                    },
                    onError: (e: any) => {
                      setState("error");
                      setSubtitle("Wake failed");
                      toast({
                        title: "Wake failed",
                        description: e?.message ?? "Unknown error",
                        variant: "destructive",
                      });
                    },
                  },
                );
              }}
              onSendText={(t) => {
                setLastUserTranscript(t);
                runTextTurn(t);
              }}
              onSetPose={(p) => setPose(p)}
              pose={pose}
              busy={busy}
            />
          </div>

          <div className="glass rounded-3xl p-5">
            <div className="text-xs text-muted-foreground">System</div>
            <div className="mt-2 grid grid-cols-2 gap-2 text-xs text-muted-foreground">
              <div className="rounded-2xl border border-border/70 bg-[hsl(var(--card))/0.35] p-3">
                <div className="text-muted-foreground">Rooms</div>
                <div data-testid="stat-rooms" className="mt-1 text-lg text-foreground/95 font-semibold">
                  {roomsQ.data?.length ?? 0}
                </div>
              </div>
              <div className="rounded-2xl border border-border/70 bg-[hsl(var(--card))/0.35] p-3">
                <div className="text-muted-foreground">Movements</div>
                <div data-testid="stat-moves" className="mt-1 text-lg text-foreground/95 font-semibold">
                  {movementsQ.data?.length ?? 0}
                </div>
              </div>
            </div>

            <div className="mt-3 grid grid-cols-1 gap-2">
              <SecondaryButton
                testId="refresh-data"
                disabled={roomsQ.isFetching || movementsQ.isFetching}
                onClick={() => {
                  roomsQ.refetch();
                  movementsQ.refetch();
                }}
                className="w-full"
              >
                Refresh memory
              </SecondaryButton>
            </div>
          </div>
        </div>
      </div>
    </KioskShell>
  );
}
