import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Camera, Bluetooth, AlertTriangle, MapPin, ChevronLeft } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

export default function SpatialAwareness() {
  const [isScanning, setIsScanning] = useState(false);
  const [bluetoothStatus, setBluetoothStatus] = useState<"disconnected" | "connecting" | "connected">("disconnected");
  const [detectedObstacles, setDetectedObstacles] = useState<string[]>([]);
  const [currentRoom, setCurrentRoom] = useState<string>("Unknown");
  const videoRef = useRef<HTMLVideoElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    let stream: MediaStream | null = null;
    if (isScanning) {
      navigator.mediaDevices.getUserMedia({ video: true })
        .then(s => {
          stream = s;
          if (videoRef.current) videoRef.current.srcObject = s;
        })
        .catch(err => {
          toast({
            title: "Camera Error",
            description: "Could not access camera feed.",
            variant: "destructive"
          });
          setIsScanning(false);
        });
    }
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [isScanning, toast]);

  // Simulated CV analysis
  useEffect(() => {
    if (!isScanning) return;
    const interval = setInterval(() => {
      const obstacles = ["Chair", "Table Leg", "Wall", "Person", "Pet"];
      const randomObstacle = obstacles[Math.floor(Math.random() * obstacles.length)];
      setDetectedObstacles(prev => [randomObstacle, ...prev].slice(0, 5));
      
      const rooms = ["Kitchen", "Living Room", "Bedroom", "Hallway"];
      const room = rooms[Math.floor(Math.random() * rooms.length)];
      setCurrentRoom(room);

      // Simulated Bluetooth transmission to ESP32
      if (bluetoothStatus === "connected") {
        console.log(`Sending data to Nacho: Room=${room}, Obstacle=${randomObstacle}`);
      }
    }, 2000);
    return () => clearInterval(interval);
  }, [isScanning, bluetoothStatus]);

  const connectBluetooth = () => {
    setBluetoothStatus("connecting");
    setTimeout(() => {
      setBluetoothStatus("connected");
      toast({
        title: "Connected to Nacho",
        description: "ESP32 Bluetooth connection established.",
      });
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon" data-testid="link-back-home">
                <ChevronLeft className="h-6 w-6" />
              </Button>
            </Link>
            <h1 className="text-3xl font-bold tracking-tight">Spatial Awareness</h1>
          </div>
          <div className="flex gap-2">
            <Button 
              variant={bluetoothStatus === "connected" ? "default" : "outline"}
              onClick={connectBluetooth}
              disabled={bluetoothStatus !== "disconnected"}
              data-testid="button-connect-bluetooth"
            >
              <Bluetooth className="mr-2 h-4 w-4" />
              {bluetoothStatus === "connected" ? "Nacho Connected" : bluetoothStatus === "connecting" ? "Connecting..." : "Connect Nacho"}
            </Button>
            <Button 
              variant={isScanning ? "destructive" : "default"}
              onClick={() => setIsScanning(!isScanning)}
              data-testid="button-toggle-camera"
            >
              <Camera className="mr-2 h-4 w-4" />
              {isScanning ? "Stop Feed" : "Start Feed"}
            </Button>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 overflow-hidden bg-muted relative min-h-[400px] flex items-center justify-center">
            {isScanning ? (
              <>
                <video 
                  ref={videoRef} 
                  autoPlay 
                  playsInline 
                  className="absolute inset-0 w-full h-full object-cover opacity-50"
                />
                <div className="absolute inset-0 border-2 border-primary/30 pointer-events-none animate-pulse" />
                <div className="relative z-10 text-center space-y-2">
                  <Badge variant="secondary" className="bg-primary/20 text-primary-foreground border-primary/50">
                    CV Analysis Active
                  </Badge>
                  <p className="text-sm font-medium">Analyzing environment for Nacho...</p>
                </div>
              </>
            ) : (
              <div className="text-center space-y-4 p-8">
                <div className="bg-background/50 rounded-full p-6 inline-block">
                  <Camera className="h-12 w-12 text-muted-foreground" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold">Camera Feed Offline</h3>
                  <p className="text-sm text-muted-foreground">Start the feed to begin spatial detection</p>
                </div>
              </div>
            )}
          </Card>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-primary" />
                  Room Location
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary" data-testid="text-current-room">
                  {currentRoom}
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  Transmitting to Nacho via ESP32
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-destructive">
                  <AlertTriangle className="h-5 w-5" />
                  Detected Obstacles
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {detectedObstacles.length > 0 ? (
                    detectedObstacles.map((obs, i) => (
                      <div key={i} className="flex items-center justify-between p-2 rounded bg-destructive/10 text-destructive text-sm" data-testid={`text-obstacle-${i}`}>
                        <span>{obs} detected</span>
                        <Badge variant="outline" className="text-[10px] uppercase">Avoid</Badge>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground italic">No immediate obstacles detected</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
