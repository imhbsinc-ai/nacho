import { useMutation } from "@tanstack/react-query";
import { api, type WakeInput } from "@shared/routes";
import { parseWithLogging } from "@/hooks/_parse";

export function useWake() {
  return useMutation({
    mutationFn: async (input: WakeInput) => {
      const validated = api.wake.create.input.parse(input);
      const res = await fetch(api.wake.create.path, {
        method: api.wake.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const err = parseWithLogging(
            api.wake.create.responses[400],
            await res.json(),
            "wake.create 400",
          );
          throw new Error(err.message);
        }
        throw new Error("Failed to wake Nacho");
      }

      return parseWithLogging(
        api.wake.create.responses[200],
        await res.json(),
        "wake.create 200",
      );
    },
  });
}
