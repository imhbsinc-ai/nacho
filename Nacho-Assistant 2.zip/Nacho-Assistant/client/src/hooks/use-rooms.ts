import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type SaveRoomInput } from "@shared/routes";
import { parseWithLogging } from "@/hooks/_parse";

export function useRooms() {
  return useQuery({
    queryKey: [api.rooms.list.path],
    queryFn: async () => {
      const res = await fetch(api.rooms.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch rooms");
      return parseWithLogging(
        api.rooms.list.responses[200],
        await res.json(),
        "rooms.list 200",
      );
    },
  });
}

export function useSaveRoom() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: SaveRoomInput) => {
      const validated = api.rooms.create.input.parse(input);
      const res = await fetch(api.rooms.create.path, {
        method: api.rooms.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const err = parseWithLogging(
            api.rooms.create.responses[400],
            await res.json(),
            "rooms.create 400",
          );
          throw new Error(err.message);
        }
        throw new Error("Failed to save room");
      }

      return parseWithLogging(
        api.rooms.create.responses[201],
        await res.json(),
        "rooms.create 201",
      );
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [api.rooms.list.path] });
    },
  });
}

export function useSetHomeBase() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.rooms.setHomeBase.path, { id });
      const validated = api.rooms.setHomeBase.input?.parse({});
      const res = await fetch(url, {
        method: api.rooms.setHomeBase.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated ?? {}),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 404) {
          const err = parseWithLogging(
            api.rooms.setHomeBase.responses[404],
            await res.json(),
            "rooms.setHomeBase 404",
          );
          throw new Error(err.message);
        }
        throw new Error("Failed to set home base");
      }

      return parseWithLogging(
        api.rooms.setHomeBase.responses[200],
        await res.json(),
        "rooms.setHomeBase 200",
      );
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [api.rooms.list.path] });
    },
  });
}
