import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, type MoveInput } from "@shared/routes";
import { parseWithLogging } from "@/hooks/_parse";

export function useMovements(limit?: number) {
  return useQuery({
    queryKey: [api.move.list.path, { limit: limit ?? null }],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (typeof limit === "number") params.set("limit", String(limit));

      const url = params.toString()
        ? `${api.move.list.path}?${params.toString()}`
        : api.move.list.path;

      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch movements");
      return parseWithLogging(
        api.move.list.responses[200],
        await res.json(),
        "move.list 200",
      );
    },
  });
}

export function useCreateMove() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: MoveInput) => {
      const validated = api.move.create.input.parse(input);
      const res = await fetch(api.move.create.path, {
        method: api.move.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const err = parseWithLogging(
            api.move.create.responses[400],
            await res.json(),
            "move.create 400",
          );
          throw new Error(err.message);
        }
        throw new Error("Failed to create movement");
      }

      return parseWithLogging(
        api.move.create.responses[201],
        await res.json(),
        "move.create 201",
      );
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [api.move.list.path] });
    },
  });
}

export function useStopMove() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const validated = api.move.stop.input?.parse({});
      const res = await fetch(api.move.stop.path, {
        method: api.move.stop.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated ?? {}),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to stop movement");
      return parseWithLogging(
        api.move.stop.responses[200],
        await res.json(),
        "move.stop 200",
      );
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [api.move.list.path] });
    },
  });
}
