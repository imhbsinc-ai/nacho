import { useMutation } from "@tanstack/react-query";
import { api, type ChatInput } from "@shared/routes";
import { parseWithLogging } from "@/hooks/_parse";

export function useChat() {
  return useMutation({
    mutationFn: async (input: ChatInput) => {
      const validated = api.chat.create.input.parse(input);
      const res = await fetch(api.chat.create.path, {
        method: api.chat.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const err = parseWithLogging(
            api.chat.create.responses[400],
            await res.json(),
            "chat.create 400",
          );
          throw new Error(err.message);
        }
        if (res.status === 500) {
          const err = parseWithLogging(
            api.chat.create.responses[500],
            await res.json(),
            "chat.create 500",
          );
          throw new Error(err.message);
        }
        throw new Error("Failed to chat");
      }

      return parseWithLogging(
        api.chat.create.responses[200],
        await res.json(),
        "chat.create 200",
      );
    },
  });
}
