import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";

/**
 * Voice routes are not fully specified with Zod in shared/routes.ts (blueprint module),
 * so we keep runtime-safe handling here while still using api.*.path as the URL source of truth.
 */

export type ConversationListItem = {
  id: number;
  title: string;
  createdAt: string | Date;
};

export type ConversationWithMessages = {
  id: number;
  title: string;
  createdAt: string | Date;
  messages: Array<{
    id: number;
    conversationId: number;
    role: string;
    content: string;
    createdAt: string | Date;
  }>;
};

export function useVoiceConversations() {
  return useQuery({
    queryKey: [api.voice.conversations.list.path],
    queryFn: async () => {
      const res = await fetch(api.voice.conversations.list.path, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch conversations");
      return (await res.json()) as ConversationListItem[];
    },
  });
}

export function useVoiceConversation(id: number) {
  return useQuery({
    queryKey: [api.voice.conversations.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.voice.conversations.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch conversation");
      return (await res.json()) as ConversationWithMessages;
    },
    enabled: Number.isFinite(id),
  });
}

export function useCreateConversation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (title?: string) => {
      const res = await fetch(api.voice.conversations.create.path, {
        method: api.voice.conversations.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: title ?? "New Chat" }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create conversation");
      return (await res.json()) as ConversationListItem;
    },
    onSuccess: () =>
      qc.invalidateQueries({ queryKey: [api.voice.conversations.list.path] }),
  });
}

export function useDeleteConversation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.voice.conversations.delete.path, { id });
      const res = await fetch(url, {
        method: api.voice.conversations.delete.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to delete conversation");
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [api.voice.conversations.list.path] });
    },
  });
}
