import React, { useMemo, useState } from "react";
import { cn } from "@/lib/utils";
import { ChevronDown, ChevronUp, Code2, Send, Sparkles } from "lucide-react";
import { SecondaryButton } from "@/components/SecondaryButton";
import { PrimaryButton } from "@/components/PrimaryButton";

export type SimPose = { x: number; y: number; heading: number };

export function DevPanel({
  open,
  onToggle,
  onWakeClick,
  onSendText,
  onSetPose,
  pose,
  busy,
  className,
}: {
  open: boolean;
  onToggle: () => void;
  onWakeClick: () => void;
  onSendText: (text: string) => void;
  onSetPose: (pose: SimPose) => void;
  pose: SimPose;
  busy: boolean;
  className?: string;
}) {
  const [text, setText] = useState("");
  const [x, setX] = useState(String(pose.x));
  const [y, setY] = useState(String(pose.y));
  const [h, setH] = useState(String(pose.heading));

  const canSend = useMemo(() => text.trim().length > 0 && !busy, [text, busy]);

  return (
    <div className={cn("glass rounded-3xl overflow-hidden", className)}>
      <button
        data-testid="devpanel-toggle"
        onClick={onToggle}
        className={cn(
          "w-full flex items-center justify-between px-5 py-4",
          "hover:bg-white/5 transition-colors duration-200 focus:outline-none focus:ring-4 focus:ring-ring/20",
        )}
      >
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-2xl bg-[linear-gradient(180deg,hsl(var(--accent))/0.9,hsl(var(--accent))/0.55)] text-accent-foreground flex items-center justify-center shadow-[0_18px_50px_hsl(var(--accent)/0.18)]">
            <Code2 className="h-5 w-5" />
          </div>
          <div className="text-left">
            <div className="font-semibold tracking-tight">Developer Panel</div>
            <div className="text-xs text-muted-foreground">
              Keyboard wake + pose simulator
            </div>
          </div>
        </div>
        {open ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
      </button>

      {open ? (
        <div className="px-5 pb-5">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="rounded-2xl border border-border/70 bg-[hsl(var(--card))/0.35] p-4">
              <div className="text-xs text-muted-foreground">Text fallback</div>
              <div className="mt-2 flex gap-2">
                <input
                  data-testid="devpanel-text"
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder='Try: "hey nacho, go to kitchen"'
                  className={cn(
                    "w-full px-4 py-3 rounded-2xl",
                    "bg-[hsl(var(--background))/0.35] border border-border/80",
                    "text-foreground placeholder:text-muted-foreground",
                    "focus:outline-none focus:ring-4 focus:ring-ring/20 focus:border-ring",
                    "transition-all duration-200",
                  )}
                />
                <SecondaryButton
                  testId="devpanel-wake"
                  disabled={busy}
                  onClick={onWakeClick}
                  className="whitespace-nowrap"
                >
                  <Sparkles className="h-4 w-4" />
                  Wake
                </SecondaryButton>
              </div>
              <div className="mt-3">
                <PrimaryButton
                  testId="devpanel-send"
                  disabled={!canSend}
                  onClick={() => {
                    const t = text.trim();
                    if (!t) return;
                    onSendText(t);
                    setText("");
                  }}
                  className="w-full"
                >
                  <Send className="h-5 w-5" />
                  Send text
                </PrimaryButton>
              </div>
            </div>

            <div className="rounded-2xl border border-border/70 bg-[hsl(var(--card))/0.35] p-4">
              <div className="text-xs text-muted-foreground">Simulated robot pose</div>
              <div className="mt-3 grid grid-cols-3 gap-2">
                {[
                  { label: "x", v: x, set: setX },
                  { label: "y", v: y, set: setY },
                  { label: "heading", v: h, set: setH },
                ].map((f) => (
                  <label key={f.label} className="text-xs text-muted-foreground">
                    <div className="mb-1">{f.label}</div>
                    <input
                      data-testid={`devpanel-pose-${f.label}`}
                      value={f.v}
                      onChange={(e) => f.set(e.target.value)}
                      inputMode="decimal"
                      className={cn(
                        "w-full px-3 py-3 rounded-2xl",
                        "bg-[hsl(var(--background))/0.35] border border-border/80",
                        "text-foreground placeholder:text-muted-foreground",
                        "focus:outline-none focus:ring-4 focus:ring-ring/20 focus:border-ring",
                        "transition-all duration-200",
                      )}
                    />
                  </label>
                ))}
              </div>
              <div className="mt-3">
                <SecondaryButton
                  testId="devpanel-apply-pose"
                  disabled={busy}
                  onClick={() => {
                    const next = {
                      x: Number(x) || 0,
                      y: Number(y) || 0,
                      heading: Number(h) || 0,
                    };
                    onSetPose(next);
                  }}
                  className="w-full"
                >
                  Apply pose
                </SecondaryButton>
              </div>
              <div className="mt-2 text-xs text-muted-foreground">
                Current pose:{" "}
                <span className="font-mono text-foreground/90">
                  {JSON.stringify(pose)}
                </span>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
