import React, { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}

export function MicMeter({
  active,
  className,
  testId,
}: {
  active: boolean;
  className?: string;
  testId?: string;
}) {
  const [level, setLevel] = useState(0);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    if (!active) {
      setLevel(0);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      return;
    }
    const tick = () => {
      setLevel((prev) => {
        const target = 0.22 + Math.random() * 0.78;
        const next = prev + (target - prev) * 0.18;
        return clamp(next, 0, 1);
      });
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [active]);

  const bars = Array.from({ length: 10 });

  return (
    <div
      data-testid={testId}
      className={cn(
        "glass rounded-2xl px-4 py-3 w-full max-w-md glow-ring",
        className,
      )}
    >
      <div className="flex items-center justify-between">
        <div className="text-xs text-muted-foreground">Mic activity</div>
        <div className="text-xs text-muted-foreground tabular-nums">
          {active ? `${Math.round(level * 100)}%` : "—"}
        </div>
      </div>

      <div className="mt-2 flex items-end gap-1.5 h-10">
        {bars.map((_, i) => {
          const t = i / (bars.length - 1);
          const h = 8 + 32 * clamp(level * (0.55 + t * 0.75), 0, 1);
          const hot = level > 0.72;
          return (
            <div
              key={i}
              className={cn(
                "w-full rounded-lg transition-all duration-200",
                hot
                  ? "bg-[linear-gradient(180deg,hsl(var(--destructive)),hsl(var(--accent)))]"
                  : "bg-[linear-gradient(180deg,hsl(var(--primary)),hsl(var(--chart-3)))]",
                active ? "opacity-100" : "opacity-30",
              )}
              style={{ height: `${h}px` }}
            />
          );
        })}
      </div>
    </div>
  );
}
