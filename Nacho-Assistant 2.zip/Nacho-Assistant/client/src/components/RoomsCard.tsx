import React, { useMemo, useState } from "react";
import { Room } from "@shared/schema";
import { Home, MapPin, Plus, Star } from "lucide-react";
import { cn } from "@/lib/utils";
import { SecondaryButton } from "@/components/SecondaryButton";
import { PrimaryButton } from "@/components/PrimaryButton";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export function RoomsCard({
  rooms,
  onSetHomeBase,
  onSaveRoom,
  saving,
  settingHome,
  pose,
  className,
}: {
  rooms: Room[];
  onSetHomeBase: (id: number) => void;
  onSaveRoom: (input: { room_name: string; location_data: unknown; is_home_base?: boolean }) => void;
  saving: boolean;
  settingHome: boolean;
  pose: unknown;
  className?: string;
}) {
  const home = useMemo(() => rooms.find((r) => r.isHomeBase), [rooms]);
  const [open, setOpen] = useState(false);
  const [roomName, setRoomName] = useState("");
  const [makeHome, setMakeHome] = useState(false);

  return (
    <div className={cn("glass rounded-3xl p-5 md:p-6", className)}>
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <MapPin className="h-5 w-5 text-primary" />
            <h2 className="text-xl md:text-2xl">Rooms</h2>
          </div>
          <p className="mt-1 text-sm text-muted-foreground">
            Memory locations you can navigate to.
          </p>
        </div>

        <SecondaryButton
          testId="rooms-add"
          disabled={saving}
          onClick={() => setOpen(true)}
        >
          <Plus className="h-4 w-4" />
          Add
        </SecondaryButton>
      </div>

      <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
        {rooms.length === 0 ? (
          <div className="rounded-2xl border border-border/70 bg-[hsl(var(--card))/0.35] p-5 text-sm text-muted-foreground">
            No rooms yet. Say “this is the kitchen” or add one here.
          </div>
        ) : (
          rooms.map((r) => (
            <div
              key={r.id}
              className={cn(
                "rounded-2xl border border-border/70 bg-[hsl(var(--card))/0.35] p-4",
                "transition-all duration-300",
                "hover:-translate-y-0.5 hover:shadow-[0_18px_60px_hsl(220_35%_2%/0.45)]",
              )}
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold tracking-tight text-foreground/95">
                    {r.name}
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground line-clamp-2">
                    {home?.id === r.id ? "Home base" : "Saved location"} •{" "}
                    <span className="font-mono">
                      {JSON.stringify(r.locationData).slice(0, 64)}
                      {JSON.stringify(r.locationData).length > 64 ? "…" : ""}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {r.isHomeBase ? (
                    <div className="inline-flex items-center gap-1 rounded-xl px-2.5 py-1 bg-primary/12 text-primary text-xs border border-primary/25">
                      <Home className="h-3.5 w-3.5" />
                      Home
                    </div>
                  ) : (
                    <button
                      data-testid={`rooms-set-home-${r.id}`}
                      onClick={() => onSetHomeBase(r.id)}
                      disabled={settingHome}
                      className={cn(
                        "inline-flex items-center gap-1 rounded-xl px-2.5 py-1",
                        "bg-[hsl(var(--background))/0.35] border border-border/80",
                        "text-xs text-foreground/90",
                        "hover:bg-white/5 hover:border-border",
                        "focus:outline-none focus:ring-4 focus:ring-ring/20",
                        "disabled:opacity-50 disabled:cursor-not-allowed",
                        "transition-all duration-200",
                      )}
                    >
                      <Star className="h-3.5 w-3.5" />
                      Set home
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-[560px]">
          <DialogHeader>
            <DialogTitle className="text-2xl">Save room</DialogTitle>
          </DialogHeader>

          <div className="mt-2 space-y-4">
            <div>
              <label className="text-xs text-muted-foreground">Room name</label>
              <input
                data-testid="rooms-name"
                value={roomName}
                onChange={(e) => setRoomName(e.target.value)}
                placeholder="Kitchen"
                className={cn(
                  "mt-2 w-full px-4 py-3 rounded-2xl",
                  "bg-[hsl(var(--background))/0.35] border border-border/80",
                  "text-foreground placeholder:text-muted-foreground",
                  "focus:outline-none focus:ring-4 focus:ring-ring/20 focus:border-ring",
                  "transition-all duration-200",
                )}
              />
            </div>

            <label className="flex items-center gap-3 rounded-2xl border border-border/70 bg-[hsl(var(--card))/0.35] px-4 py-3">
              <input
                data-testid="rooms-make-home"
                type="checkbox"
                checked={makeHome}
                onChange={(e) => setMakeHome(e.target.checked)}
                className="h-5 w-5 accent-[hsl(var(--primary))]"
              />
              <div>
                <div className="font-semibold tracking-tight">Make this home base</div>
                <div className="text-xs text-muted-foreground">
                  “Return home base” will navigate here.
                </div>
              </div>
            </label>

            <div className="rounded-2xl border border-border/70 bg-[hsl(var(--card))/0.35] p-4">
              <div className="text-xs text-muted-foreground">Location data</div>
              <pre className="mt-2 text-xs overflow-auto text-foreground/85 font-mono">
                {JSON.stringify(pose, null, 2)}
              </pre>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <SecondaryButton
                testId="rooms-cancel"
                disabled={saving}
                onClick={() => setOpen(false)}
              >
                Cancel
              </SecondaryButton>
              <PrimaryButton
                testId="rooms-save"
                disabled={saving || roomName.trim().length === 0}
                onClick={() => {
                  const name = roomName.trim();
                  if (!name) return;
                  onSaveRoom({
                    room_name: name,
                    location_data: pose,
                    is_home_base: makeHome || undefined,
                  });
                  setRoomName("");
                  setMakeHome(false);
                  setOpen(false);
                }}
              >
                {saving ? "Saving…" : "Save room"}
              </PrimaryButton>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
