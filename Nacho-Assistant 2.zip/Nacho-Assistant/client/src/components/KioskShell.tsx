import React from "react";
import { cn } from "@/lib/utils";

export function KioskShell({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("min-h-screen kiosk-bg relative overflow-hidden", className)}>
      <div className="absolute inset-0 grain" />
      <div className="relative z-10 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 min-h-screen py-6 md:py-10">
          {children}
        </div>
      </div>
    </div>
  );
}
