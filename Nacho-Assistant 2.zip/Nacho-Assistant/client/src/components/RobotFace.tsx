import React, { useEffect, useMemo, useState } from "react";
import { cn } from "@/lib/utils";
import type { NachoState } from "@/components/StatusPill";

function useMouth(level: number, active: boolean) {
  const [phase, setPhase] = useState(0);
  useEffect(() => {
    if (!active) {
      setPhase(0);
      return;
    }
    const i = setInterval(() => setPhase((p) => (p + 1) % 12), 90);
    return () => clearInterval(i);
  }, [active]);

  const open = active ? 0.35 + 0.55 * (0.4 + 0.6 * Math.abs(Math.sin(phase / 2))) : 0.15;
  return clamp(open * (0.55 + level * 0.85), 0, 1);
}

function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}

export function RobotFace({
  state,
  subtitle,
  className,
  testId,
}: {
  state: NachoState;
  subtitle?: string;
  className?: string;
  testId?: string;
}) {
  const [pulse, setPulse] = useState(0.2);

  useEffect(() => {
    const t = setInterval(() => setPulse(0.15 + Math.random() * 0.85), 180);
    return () => clearInterval(t);
  }, []);

  const speaking = state === "speaking";
  const listening = state === "listening";
  const thinking = state === "thinking";
  const navigating = state === "navigating";
  const error = state === "error";

  const mouthOpen = useMouth(pulse, speaking);

  const aura = useMemo(() => {
    if (error)
      return "from-destructive/30 via-[hsl(var(--chart-5))/0.08] to-transparent";
    if (navigating)
      return "from-[hsl(var(--chart-4))/0.26] via-[hsl(var(--primary))/0.06] to-transparent";
    if (speaking)
      return "from-[hsl(var(--chart-3))/0.26] via-[hsl(var(--primary))/0.10] to-transparent";
    if (thinking)
      return "from-accent/24 via-[hsl(var(--chart-3))/0.08] to-transparent";
    if (listening)
      return "from-primary/28 via-[hsl(var(--chart-3))/0.08] to-transparent";
    return "from-primary/12 via-[hsl(var(--chart-3))/0.06] to-transparent";
  }, [error, navigating, speaking, thinking, listening]);

  return (
    <div
      data-testid={testId}
      className={cn(
        "relative mx-auto w-full max-w-[720px] aspect-square rounded-[2.25rem] glass glow-ring overflow-hidden",
        "animate-float-in",
        className,
      )}
    >
      <div className={cn("absolute inset-0 bg-gradient-to-b", aura)} />

      <div className="absolute inset-0">
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 h-72 w-[42rem] rounded-full blur-3xl opacity-80 shimmer" />
      </div>

      <div className="relative h-full flex flex-col items-center justify-center p-8 md:p-10">
        <div className="w-full flex items-center justify-center">
          <div className="relative w-full max-w-[520px]">
            <div
              className={cn(
                "absolute -inset-10 rounded-[3rem] blur-2xl opacity-55 transition-all duration-300",
                listening && "bg-primary/18",
                thinking && "bg-accent/16",
                speaking && "bg-[hsl(var(--chart-3))]/16",
                navigating && "bg-[hsl(var(--chart-4))]/14",
                error && "bg-destructive/18",
                state === "idle" && "bg-primary/10",
              )}
            />

            {/* Eyes */}
            <div className="relative grid grid-cols-2 gap-10 sm:gap-14 items-center justify-items-center">
              {(["left", "right"] as const).map((side) => {
                const focused = navigating || listening;
                const confused = error;
                return (
                  <div
                    key={side}
                    className={cn(
                      "relative h-28 w-28 sm:h-32 sm:w-32 rounded-[2rem] soft-outline bg-[hsl(var(--card))/0.55]",
                      "transition-all duration-300",
                      focused && "scale-[1.03] shadow-[0_0_0_1px_hsl(var(--primary)/0.35),0_20px_60px_hsl(var(--primary)/0.10)]",
                      confused && "rotate-[-4deg]",
                      side === "right" && confused && "rotate-[4deg]",
                    )}
                  >
                    <div
                      className={cn(
                        "absolute inset-0 rounded-[2rem] bg-gradient-to-b from-white/10 to-transparent",
                      )}
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div
                        className={cn(
                          "h-10 w-16 sm:h-11 sm:w-20 rounded-full bg-foreground/95 shadow-[0_12px_30px_hsl(220_35%_2%/0.35)]",
                          state === "idle" ? "blink" : "",
                          thinking ? "opacity-85" : "opacity-100",
                        )}
                        style={{
                          transform: confused ? "translateY(2px) scaleX(0.95)" : undefined,
                        }}
                      />
                    </div>

                    {/* Iris glow */}
                    <div
                      className={cn(
                        "absolute inset-0 rounded-[2rem] opacity-0 transition-opacity duration-300",
                        (listening || speaking) && "opacity-100",
                      )}
                    >
                      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-28 w-28 rounded-full blur-2xl bg-primary/18" />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Mouth */}
            <div className="mt-10 sm:mt-12 flex items-center justify-center">
              <div
                className={cn(
                  "relative w-[64%] max-w-[340px] rounded-[999px] soft-outline overflow-hidden",
                  "bg-[hsl(var(--card))/0.55]",
                  "transition-all duration-300",
                  speaking ? "shadow-[0_0_0_1px_hsl(var(--chart-3)/0.35),0_24px_60px_hsl(var(--chart-3)/0.10)]" : "",
                  error ? "rotate-[-6deg]" : "",
                )}
                style={{
                  height: `${26 + mouthOpen * 56}px`,
                }}
              >
                <div className="absolute inset-0 bg-gradient-to-b from-white/10 to-transparent" />
                <div
                  className={cn(
                    "absolute inset-x-4 bottom-3 h-2 rounded-full transition-all duration-200",
                    speaking ? "bg-[hsl(var(--chart-3))]/55" : "bg-primary/35",
                  )}
                  style={{
                    transform: `scaleX(${0.8 + mouthOpen * 0.2})`,
                    opacity: 0.65 + mouthOpen * 0.25,
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 sm:mt-10 text-center">
          <h1 className="font-display text-3xl sm:text-4xl md:text-5xl tracking-tight uppercase">
            NACHO V1
          </h1>
          <p className="mt-2 text-sm sm:text-base text-muted-foreground">
            {subtitle ?? "Voice-first assistant. Say “Hey Nacho” to begin."}
          </p>
        </div>
      </div>
    </div>
  );
}
