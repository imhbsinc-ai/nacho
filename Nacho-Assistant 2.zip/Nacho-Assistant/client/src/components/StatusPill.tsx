import React from "react";
import { cn } from "@/lib/utils";
import {
  Activity,
  AlertTriangle,
  Bot,
  Mic,
  Navigation,
  Sparkles,
  Volume2,
} from "lucide-react";

export type NachoState =
  | "idle"
  | "listening"
  | "thinking"
  | "speaking"
  | "navigating"
  | "error";

const meta: Record<
  NachoState,
  { label: string; icon: React.ElementType; ring: string; dot: string }
> = {
  idle: {
    label: "Idle",
    icon: Bot,
    ring: "shadow-[0_0_0_1px_hsl(var(--border)/0.9),0_0_0_6px_hsl(var(--primary)/0.08)]",
    dot: "bg-muted-foreground/70",
  },
  listening: {
    label: "Listening",
    icon: Mic,
    ring: "shadow-[0_0_0_1px_hsl(var(--primary)/0.45),0_0_0_10px_hsl(var(--primary)/0.12)]",
    dot: "bg-primary",
  },
  thinking: {
    label: "Thinking",
    icon: Sparkles,
    ring: "shadow-[0_0_0_1px_hsl(var(--accent)/0.4),0_0_0_10px_hsl(var(--accent)/0.10)]",
    dot: "bg-accent",
  },
  speaking: {
    label: "Speaking",
    icon: Volume2,
    ring: "shadow-[0_0_0_1px_hsl(var(--primary)/0.4),0_0_0_10px_hsl(275_90%_70%/0.10)]",
    dot: "bg-[hsl(var(--chart-3))]",
  },
  navigating: {
    label: "Navigating",
    icon: Navigation,
    ring: "shadow-[0_0_0_1px_hsl(140_70%_55%/0.4),0_0_0_10px_hsl(140_70%_55%/0.10)]",
    dot: "bg-[hsl(var(--chart-4))]",
  },
  error: {
    label: "Error",
    icon: AlertTriangle,
    ring: "shadow-[0_0_0_1px_hsl(var(--destructive)/0.45),0_0_0_10px_hsl(var(--destructive)/0.12)]",
    dot: "bg-destructive",
  },
};

export function StatusPill({
  state,
  subtitle,
  className,
  testId,
}: {
  state: NachoState;
  subtitle?: string;
  className?: string;
  testId?: string;
}) {
  const Icon = meta[state].icon;
  return (
    <div
      data-testid={testId}
      className={cn(
        "inline-flex items-center gap-3 rounded-2xl px-4 py-3 glass glow-ring",
        meta[state].ring,
        className,
      )}
    >
      <span className="relative flex h-3 w-3">
        <span
          className={cn(
            "absolute inline-flex h-full w-full rounded-full opacity-60 animate-ping",
            meta[state].dot,
            state === "idle" ? "hidden" : "",
          )}
        />
        <span className={cn("relative inline-flex h-3 w-3 rounded-full", meta[state].dot)} />
      </span>
      <div className="flex flex-col leading-tight">
        <div className="flex items-center gap-2">
          <Icon className="h-4 w-4 text-foreground/90" />
          <span className="text-sm font-semibold tracking-tight text-foreground/95">
            {meta[state].label}
          </span>
          <span className="text-xs text-muted-foreground">
            <Activity className="inline h-3 w-3 -mt-0.5 mr-1 opacity-80" />
            Live
          </span>
        </div>
        {subtitle ? (
          <div className="text-xs text-muted-foreground mt-0.5">{subtitle}</div>
        ) : null}
      </div>
    </div>
  );
}
