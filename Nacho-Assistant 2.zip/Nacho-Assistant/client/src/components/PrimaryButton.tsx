import React from "react";
import { cn } from "@/lib/utils";

export function PrimaryButton({
  children,
  className,
  disabled,
  onClick,
  type = "button",
  testId,
}: {
  children: React.ReactNode;
  className?: string;
  disabled?: boolean;
  type?: "button" | "submit";
  onClick: () => void;
  testId?: string;
}) {
  return (
    <button
      data-testid={testId}
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "group relative inline-flex items-center justify-center gap-2 rounded-2xl px-6 py-4",
        "text-base sm:text-lg font-semibold tracking-tight",
        "bg-[linear-gradient(180deg,hsl(var(--primary)),hsl(var(--primary))/0.78)] text-primary-foreground",
        "shadow-[0_18px_60px_hsl(var(--primary)/0.18),0_10px_28px_hsl(220_35%_2%/0.40)]",
        "hover:shadow-[0_20px_70px_hsl(var(--primary)/0.22),0_12px_30px_hsl(220_35%_2%/0.45)] hover:-translate-y-0.5",
        "active:translate-y-0 active:shadow-[0_12px_40px_hsl(var(--primary)/0.14),0_8px_18px_hsl(220_35%_2%/0.45)]",
        "focus:outline-none focus:ring-4 focus:ring-ring/30",
        "disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none",
        "transition-all duration-200 ease-out",
        className,
      )}
    >
      <span className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-[radial-gradient(circle_at_30%_20%,hsl(0_0%_100%/0.22),transparent_55%)]" />
      <span className="relative">{children}</span>
    </button>
  );
}
