import React from "react";
import { cn } from "@/lib/utils";

export function SecondaryButton({
  children,
  className,
  disabled,
  onClick,
  testId,
}: {
  children: React.ReactNode;
  className?: string;
  disabled?: boolean;
  onClick: () => void;
  testId?: string;
}) {
  return (
    <button
      data-testid={testId}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "relative inline-flex items-center justify-center gap-2 rounded-2xl px-5 py-3",
        "text-sm sm:text-base font-semibold tracking-tight",
        "bg-[linear-gradient(180deg,hsl(var(--card))/0.75,hsl(var(--card))/0.45)]",
        "border border-border/80 text-foreground/95",
        "shadow-[0_14px_50px_hsl(220_35%_2%/0.40)]",
        "hover:-translate-y-0.5 hover:shadow-[0_18px_60px_hsl(220_35%_2%/0.45)]",
        "active:translate-y-0 active:shadow-[0_10px_38px_hsl(220_35%_2%/0.45)]",
        "focus:outline-none focus:ring-4 focus:ring-ring/25",
        "disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none",
        "transition-all duration-200 ease-out",
        className,
      )}
    >
      {children}
    </button>
  );
}
