import React from "react";
import type { Movement } from "@shared/schema";
import { cn } from "@/lib/utils";
import { CornerDownRight, StopCircle } from "lucide-react";
import { PrimaryButton } from "@/components/PrimaryButton";
import { SecondaryButton } from "@/components/SecondaryButton";

function statusTone(status: string) {
  const s = status.toLowerCase();
  if (s.includes("success") || s.includes("done") || s.includes("complete"))
    return "bg-[hsl(var(--chart-4))]/14 text-[hsl(var(--chart-4))] border-[hsl(var(--chart-4))]/25";
  if (s.includes("fail") || s.includes("error"))
    return "bg-destructive/12 text-destructive border-destructive/25";
  if (s.includes("run") || s.includes("active") || s.includes("moving"))
    return "bg-primary/12 text-primary border-primary/25";
  return "bg-accent/10 text-accent border-accent/25";
}

export function MovementCard({
  latest,
  list,
  onStop,
  stopping,
  onQuickCommand,
  busy,
  className,
}: {
  latest: Movement | null;
  list: Movement[];
  onStop: () => void;
  stopping: boolean;
  onQuickCommand: (cmd: string) => void;
  busy: boolean;
  className?: string;
}) {
  return (
    <div className={cn("glass rounded-3xl p-5 md:p-6", className)}>
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <CornerDownRight className="h-5 w-5 text-[hsl(var(--chart-4))]" />
            <h2 className="text-xl md:text-2xl">Navigation</h2>
          </div>
          <p className="mt-1 text-sm text-muted-foreground">
            Commands like “go to kitchen”, “return home base”, “stop moving”.
          </p>
        </div>

        <SecondaryButton
          testId="move-stop"
          disabled={stopping}
          onClick={onStop}
        >
          <StopCircle className="h-4 w-4" />
          Stop
        </SecondaryButton>
      </div>

      <div className="mt-4 rounded-2xl border border-border/70 bg-[hsl(var(--card))/0.35] p-4">
        <div className="text-xs text-muted-foreground">Latest movement</div>
        {latest ? (
          <div className="mt-2">
            <div className="flex flex-wrap items-center gap-2">
              <div className="font-semibold tracking-tight text-foreground/95">
                {latest.command}
              </div>
              {latest.destination ? (
                <div className="text-xs text-muted-foreground">
                  → <span className="text-foreground/90">{latest.destination}</span>
                </div>
              ) : null}
              <div
                className={cn(
                  "ml-auto inline-flex items-center rounded-xl px-2.5 py-1 text-xs border",
                  statusTone(latest.status),
                )}
              >
                {latest.status}
              </div>
            </div>
            {latest.detail ? (
              <div className="mt-2 text-xs text-muted-foreground">
                {latest.detail}
              </div>
            ) : null}
          </div>
        ) : (
          <div className="mt-2 text-sm text-muted-foreground">
            No movement yet.
          </div>
        )}
      </div>

      <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
        <PrimaryButton
          testId="quick-return-home"
          disabled={busy}
          onClick={() => onQuickCommand("return home base")}
          className="w-full"
        >
          Return home base
        </PrimaryButton>
        <SecondaryButton
          testId="quick-come-here"
          disabled={busy}
          onClick={() => onQuickCommand("come here")}
          className="w-full"
        >
          Come here
        </SecondaryButton>
      </div>

      <div className="mt-4">
        <div className="text-xs text-muted-foreground mb-2">Recent</div>
        <div className="space-y-2 max-h-44 overflow-auto pr-1">
          {list.length === 0 ? (
            <div className="text-sm text-muted-foreground">
              Once you ask Nacho to move, you’ll see history here.
            </div>
          ) : (
            list.slice(0, 8).map((m) => (
              <div
                key={m.id}
                className="rounded-2xl border border-border/70 bg-[hsl(var(--background))/0.22] px-4 py-3 flex items-center gap-3"
              >
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-foreground/95 truncate">
                    {m.command}
                  </div>
                  <div className="text-xs text-muted-foreground truncate">
                    {m.destination ? `Destination: ${m.destination}` : "No destination"} •{" "}
                    {new Date(m.createdAt as any).toLocaleTimeString()}
                  </div>
                </div>
                <div
                  className={cn(
                    "ml-auto inline-flex items-center rounded-xl px-2.5 py-1 text-xs border shrink-0",
                    statusTone(m.status),
                  )}
                >
                  {m.status}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
